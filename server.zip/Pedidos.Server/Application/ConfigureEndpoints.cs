﻿using Pedidos.Server.Domain.Entities;
using Pedidos.Server.Infra.Repositories.MongoDB;
using Pedidos.Server.Infra.Repositories.SqlServer;

namespace Pedidos.Server.Application
{
    public class ConfigureEndpoints
    {
        private readonly WebApplication _app;

        public ConfigureEndpoints(WebApplication app)
        {
            _app = app;
        }

        public void Configure()
        {
            ConfigureCustomers();
            ConfigureProducts();
            ConfigureOrders();
        }

        private void ConfigureCustomers()
        {
            // Customer Endpoints
            _app.MapGet("/api/customers", () =>
            {
                var customer = new
                {
                    Id = 1,
                    Name = "Default Customer",
                    Email = "customer@example.com",
                    Phone = "123-456-7890"
                };
                return Results.Ok(customer);
            });
        }
        private void ConfigureProducts()
        {
            // Get all products
            _app.MapGet("/api/products", async (IProductRepository productRepository) =>
            {
                var products = await productRepository.GetAllAsync();
                return Results.Ok(products);
            });

            // Get a product by ID
            _app.MapGet("/api/products/{id:int}", async (int id, IProductRepository productRepository) =>
            {
                var product = await productRepository.GetByIdAsync(id);
                return product is not null ? Results.Ok(product) : Results.NotFound();
            });

            // Create a new product
            _app.MapPost("/api/products", async (Product newProduct, IProductRepository productRepository) =>
            {
                var createdProduct = await productRepository.CreateAsync(newProduct);
                return Results.Created($"/api/products/{createdProduct.Id}", createdProduct);
            });
        }

        private void ConfigureOrders()
        {
            // Get all orders (relational DB)
            _app.MapGet("/api/orders", async (IOrderRepository orderRepository) =>
            {
                var orders = await orderRepository.GetAllAsync();
                return Results.Ok(orders);
            });

            // Get a specific order by ID (relational DB)
            _app.MapGet("/api/orders/{id:int}", async (int id, IOrderRepository orderRepository) =>
            {
                var order = await orderRepository.GetByIdAsync(id);
                return order is not null ? Results.Ok(order) : Results.NotFound();
            });

            // Create a new order (relational DB)
            _app.MapPost("/api/orders", async (Order newOrder, IOrderRepository orderRepository) =>
            {
                var createdOrder = await orderRepository.CreateAsync(newOrder);
                return Results.Created($"/api/orders/{createdOrder.Id}", createdOrder);
            });

            // Get all orders (read model from MongoDB)
            _app.MapGet("/api/orders/read-model", async (IMongoOrderRepository mongoOrderRepository) =>
            {
                var orders = await mongoOrderRepository.GetOrdersAsync();
                return Results.Ok(orders);
            });

            // Get a specific order by ID (read model from MongoDB)
            _app.MapGet("/api/orders/read-model/{id:int}", async (int id, IMongoOrderRepository mongoOrderRepository) =>
            {
                var order = await mongoOrderRepository.GetOrderByIdAsync(id);
                return order is not null ? Results.Ok(order) : Results.NotFound();
            });

        }

    }
}
